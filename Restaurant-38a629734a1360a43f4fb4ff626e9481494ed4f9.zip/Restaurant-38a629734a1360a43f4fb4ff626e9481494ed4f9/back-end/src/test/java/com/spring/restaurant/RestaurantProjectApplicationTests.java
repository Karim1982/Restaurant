package com.spring.restaurant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestaurantProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
